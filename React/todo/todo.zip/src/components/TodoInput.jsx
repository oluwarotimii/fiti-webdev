import { useState } from 'react';


const TodoInput = ({ onAddTodo }) => {
  const [inputValue, setInputValue] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onAddTodo(inputValue);
    setInputValue('');
  };

  return (
    <form onSubmit={handleSubmit} className="todo-input-form">
      <input
        type="text"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        placeholder="Add a new todo..."
        className="form-control"
      />
      <button type="submit" className="btn btn-primary">Add</button>
    </form>
  );
};

export default TodoInput;
// import { useState } from "react"

// const TodoInput = ({OnAddTodo}) => {
//   const [inputValue, setInputValue] = useState('')
//   const handleSubmit = (event) => {
//     event.preventDefault();
//     OnAddTodo(inputValue)
//     setInputValue('');
//   }

//   return (
//     <>
//       <h1> FILL IN THER ITEM!</h1>
//       <form
//         onSubmit={handleSubmit}
//         className="todo-input-form">

//         <input type="text"
//           // value={inputValue}
//           value='yes'
//           // onChange={(event) => setInputValue(event.target.value)}
//           onChange='hello'
//           placeholder="Add a new Item"
//           className="form-control" />

//         <button type="submit">Add Item </button>
//       </form>
//     </>
//   )
// }
// export default TodoInput