import { useState } from 'react';

const TodoItem = ({ todo, onToggle, onDelete, onSave }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);

  const handleEdit = () => {
    setIsEditing(true);
    setEditText(todo.text);
  };

  const handleSave = () => {
    if (editText.trim() !== '') {
      onSave(editText);
    }
    setIsEditing(false);
  };

  const handleCancel = () => {
    setIsEditing(false);
    setEditText(todo.text);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      handleSave();
    } else if (e.key === 'Escape') {
      handleCancel();
    }
  };

  return (
    <div className={`todo-item ${todo.completed ? 'completed' : ''}`}>
      {isEditing ? (
        <div className="edit-form">
          <input
            type="text"
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
            onKeyDown={handleKeyDown}
            autoFocus
            className="form-control"
          />
          <div className="edit-buttons">
            <button onClick={handleSave} className="btn btn-success btn-sm">Save</button>
            <button onClick={handleCancel} className="btn btn-secondary btn-sm ms-1">Cancel</button>
          </div>
        </div>
      ) : (
        <div className="todo-content">
          <div className="form-check">
            <input
              type="checkbox"
              checked={todo.completed}
              onChange={onToggle}
              className="form-check-input"
            />
            <label 
              className={`form-check-label ${todo.completed ? 'completed-text' : ''}`}
              onDoubleClick={handleEdit}
            >
              {todo.text}
            </label>
          </div>
          <div className="todo-actions">
            <button onClick={handleEdit} className="btn btn-sm btn-outline-primary">Edit</button>
            <button onClick={onDelete} className="btn btn-sm btn-outline-danger ms-1">Delete</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default TodoItem;